package com.example.mylia.Activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.mylia.databinding.ActivitySettingBinding

class Setting_Activity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.backleftIcon.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
        binding.MyProfile.setOnClickListener {
            startActivity(Intent(this, Myprofile_Activity::class.java))
        }
        binding.MyCharacterslay.setOnClickListener {
            val intent = Intent(this, My_CharactersActivity::class.java)
            intent.putExtra("caller", "Setting_Activity") // Indicate Setting_Activity as caller
            startActivity(intent)
        }
    }
}