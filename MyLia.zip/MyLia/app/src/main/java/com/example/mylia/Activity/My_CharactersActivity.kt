package com.example.mylia.Activity

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.res.ResourcesCompat
import com.example.mylia.R
import com.example.mylia.Activity.Setting_Activity
import com.example.mylia.databinding.ActivityMyCharactersBinding

class My_CharactersActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMyCharactersBinding
    private var selectedOrientationButton: AppCompatButton? = null
    private var selectedRelationshipButton: AppCompatButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyCharactersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val orientationButtons = listOf(
            binding.btnHeterosexual,
            binding.btnLesbian,
            binding.btnBisexual
        )

        val relationshipButtons = listOf(
            binding.btnGirlfriend,
            binding.btnStepMom,
            binding.btnWife,
            binding.btnLover,
            binding.btnFriend,
            binding.btnStranger
        )

        // Orientation button clicks
        orientationButtons.forEach { button ->
            button.setOnClickListener {
                selectedOrientationButton?.isSelected = false
                selectedOrientationButton = button
                button.isSelected = true
                updateContinueButton()
            }
        }

        // Relationship button clicks
        relationshipButtons.forEach { button ->
            button.setOnClickListener {
                selectedRelationshipButton?.isSelected = false
                selectedRelationshipButton = button
                button.isSelected = true
                updateContinueButton()
            }
        }

        // Text watcher for name
        binding.etGirlName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateContinueButton()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Back button
        binding.backleftIcon.setOnClickListener { navigateBack() }

        updateContinueButton()
    }

    private fun updateContinueButton() {
        val isNameFilled = binding.etGirlName.text.toString().trim().isNotEmpty()
        val isOrientationSelected = selectedOrientationButton != null
        val isRelationshipSelected = selectedRelationshipButton != null

        binding.btnContinue.isEnabled = isNameFilled && isOrientationSelected && isRelationshipSelected
        binding.btnContinue.backgroundTintList = ResourcesCompat.getColorStateList(
            resources,
            if (binding.btnContinue.isEnabled) R.color.purple_500 else R.color.gray_500,
            theme
        )
    }

    private fun navigateBack() {
        val caller = intent.getStringExtra("caller")
        when (caller) {
            "MainActivity" -> startActivity(Intent(this, MainActivity::class.java))
            "Setting_Activity" -> startActivity(Intent(this, Setting_Activity::class.java))
            else -> startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
    }

    override fun onBackPressed() {
        navigateBack()
    }
}