package com.example.mylia.Activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.mylia.Activity.Setting_Activity
import com.example.mylia.databinding.ActivityMyprofileBinding

class Myprofile_Activity : AppCompatActivity() {

    private lateinit var binding: ActivityMyprofileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
         binding = ActivityMyprofileBinding.inflate(layoutInflater)
        setContentView(binding.root)

            binding.profilebackleftIcon.setOnClickListener {
                startActivity(Intent(this, Setting_Activity::class.java))
            }
        binding.Expensesrecordlayout.setOnClickListener {
                startActivity(Intent(this, Expensesrecord_Activity::class.java))
            }

    }
}