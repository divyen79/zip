package com.example.mylia.Activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.mylia.Activity.Myprofile_Activity
import com.example.mylia.R
import com.example.mylia.databinding.ActivityExpensesrecordBinding

class Expensesrecord_Activity : AppCompatActivity() {

    private lateinit var binding: ActivityExpensesrecordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
         setContentView(R.layout.activity_expensesrecord)
        binding = ActivityExpensesrecordBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.ExpensesrecordbackleftIcon.setOnClickListener {
            startActivity(Intent(this, Myprofile_Activity::class.java))
        }
    }
}