package com.example.mylia.Activity

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.mylia.Activity.My_CharactersActivity
import com.example.mylia.R
import com.example.mylia.databinding.ActivityAvatarSelectionBinding

class activity_avatar_selection : AppCompatActivity() {

    private lateinit var binding: ActivityAvatarSelectionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAvatarSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val previewAvatar: ImageView = binding.previewAvatar
        val avatarContainer: GridLayout = binding.avatarContainer
        val btnContinue = binding.btnContinue

        // List of avatar resources (ensure unique drawables)
        val avatars = listOf(
            R.drawable.chooseavatar1,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2,
            R.drawable.avatar2
        )

        // Clear any existing background or image
        previewAvatar.setImageDrawable(null)
        previewAvatar.setBackgroundResource(0)

        // Set initial preview avatar
        previewAvatar.setImageResource(avatars[0])

        // Add avatars with crowns to GridLayout (2 rows, 8 columns)
        avatars.forEachIndexed { index, avatarRes ->
            // Create a FrameLayout to stack avatar and crown
            val frameLayout = FrameLayout(this).apply {
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 120 // Consistent size
                    height = 120 // Consistent size
                    setMargins(25, 10, 25, 10) // Consistent spacing
                    columnSpec = GridLayout.spec(index % 8) // Distribute across 8 columns
                    rowSpec = GridLayout.spec(index / 8)   // Distribute across 2 rows
                }
            }

            // Add avatar ImageView
            val avatarImageView = ImageView(this).apply {
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
                setImageResource(avatarRes)
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = ContextCompat.getDrawable(
                    this@activity_avatar_selection,
                    R.drawable.circle_background
                )
            }

            // Add crown ImageView
            val crownImageView = ImageView(this).apply {
                layoutParams = FrameLayout.LayoutParams(
                    50, 50 // Adjust crown size
                ).apply {
                    gravity = Gravity.BOTTOM or Gravity.END // Center at top
                    topMargin = 5 // Small margin from the top
                }
                setImageResource(R.drawable.ic_crown) // Ensure this drawable exists
            }

            // Add avatar and crown to FrameLayout
            frameLayout.addView(avatarImageView)
            frameLayout.addView(crownImageView)

            // Set click listener on FrameLayout to update preview
            frameLayout.setOnClickListener {
                previewAvatar.setImageResource(avatarRes)
                previewAvatar.setBackgroundResource(0)
            }

            avatarContainer.addView(frameLayout)
        }

        // Continue button action (replace with your logic)
        btnContinue.setOnClickListener {
            // Handle continue action
        }

        binding.backleftIconChooseavatar.setOnClickListener {
            startActivity(Intent(this, My_CharactersActivity::class.java))
        }
    }

}