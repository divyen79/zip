package com.example.mylia.ViewModel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mylia.Repository.AuthRepository
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.launch

class LoginViewModel(private val authRepository: AuthRepository) : ViewModel() {

    private val _authState = MutableLiveData<Result<FirebaseUser?>>()
    val authState: LiveData<Result<FirebaseUser?>> = _authState

    val googleSignInClient: GoogleSignInClient
        get() = authRepository.googleSignInClient

    fun initGoogleSignIn(context: Context) {
        authRepository.initGoogleSignIn(context)
    }

    fun signInAsGuest() {
        viewModelScope.launch {
            _authState.value = authRepository.signInAsGuest()
        }
    }

    fun signInWithGoogle(idToken: String) {
        viewModelScope.launch {
            _authState.value = authRepository.signInWithGoogle(idToken)
        }
    }

    fun handleGoogleSignInError(exception: Exception) {
        _authState.value = Result.failure(exception)
    }
}