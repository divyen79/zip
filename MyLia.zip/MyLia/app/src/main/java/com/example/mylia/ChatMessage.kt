package com.example.mylia

data class ChatMessage(val text: String, val isUser: Boolean, val timestamp: String)