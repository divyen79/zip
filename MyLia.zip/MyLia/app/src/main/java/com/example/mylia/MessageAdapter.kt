package com.example.mylia

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mylia.databinding.ItemMessageBinding

class MessageAdapter(private val messages: List<ChatMessage>) : RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    class MessageViewHolder(val binding: ItemMessageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val binding = ItemMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MessageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = messages[position]
        with(holder.binding) {
            userMessageLayout.visibility = if (message.isUser) View.VISIBLE else View.GONE
            aiMessageLayout.visibility = if (message.isUser) View.GONE else View.VISIBLE

            if (message.isUser) {
                userMessageText.text = message.text
                userTimestamp.text = message.timestamp
            } else {
                aiMessageText.text = message.text
                aiTimestamp.text = message.timestamp
            }
        }
    }

    override fun getItemCount(): Int = messages.size
}