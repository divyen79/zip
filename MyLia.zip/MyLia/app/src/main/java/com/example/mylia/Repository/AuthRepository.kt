package com.example.mylia.Repository

import android.content.Context
import android.util.Log
import com.example.mylia.R
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth

import kotlinx.coroutines.tasks.await

class AuthRepository {
    private val auth: FirebaseAuth = Firebase.auth
    lateinit var googleSignInClient: GoogleSignInClient
        private set

    fun initGoogleSignIn(context: Context) {
        Log.d("AuthRepository", "Initializing GoogleSignInClient")
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(context, gso)
        Log.d("AuthRepository", "GoogleSignInClient initialized")
    }

    suspend fun signInAsGuest(): Result<FirebaseUser?> {
        return try {
            val result = auth.signInAnonymously().await()
            Log.d("AuthRepository", "Guest login successful")
            Result.success(result.user)
        } catch (e: Exception) {
            Log.e("AuthRepository", "Guest login failed: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun signInWithGoogle(idToken: String): Result<FirebaseUser?> {
        return try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val result = auth.signInWithCredential(credential).await()
            Log.d("AuthRepository", "Google login successful: ${result.user?.email}")
            Result.success(result.user)
        } catch (e: Exception) {
            Log.e("AuthRepository", "Google login failed: ${e.message}")
            Result.failure(e)
        }
    }
}