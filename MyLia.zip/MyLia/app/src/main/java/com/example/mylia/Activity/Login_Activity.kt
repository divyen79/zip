package com.example.mylia.Activity

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.ViewModelProvider
import com.example.mylia.Repository.AuthRepository
import com.example.mylia.ViewModel.LoginViewModel
import com.example.mylia.ViewModel.LoginViewModelFactory
import com.example.mylia.databinding.ActivityLoginBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseUser

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var viewModel: LoginViewModel

    private val googleSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        Log.d("LoginActivity", "Google Sign-In result: ${result.resultCode}")
        if (result.resultCode == RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                account.idToken?.let {
                    Log.d("LoginActivity", "Google ID Token received")
                    viewModel.signInWithGoogle(it)
                } ?: run {
                    Log.e("LoginActivity", "Google ID Token is null")
                    viewModel.handleGoogleSignInError(Exception("Google ID Token is null"))
                }
            } catch (e: ApiException) {
                Log.e("LoginActivity", "Google Sign-In failed: ${e.statusCode}, ${e.message}")
                viewModel.handleGoogleSignInError(e)
            }
        } else {
            Log.w("LoginActivity", "Google Sign-In canceled or failed: ${result.resultCode}")
            viewModel.handleGoogleSignInError(Exception("Google Sign-In canceled"))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize ViewModel with custom factory
        val authRepository = AuthRepository()
        val viewModelFactory = LoginViewModelFactory(authRepository)
        viewModel = ViewModelProvider(this, viewModelFactory)[LoginViewModel::class.java]
        viewModel.initGoogleSignIn(this)

        // Transparent status bar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            window.statusBarColor = Color.TRANSPARENT
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            window.statusBarColor = Color.TRANSPARENT
        }

        // Button click listeners
        binding.googleLoginButton.setOnClickListener {
            Log.d("LoginActivity", "Google Login Button clicked")
            try {
                val signInIntent = viewModel.googleSignInClient.signInIntent
                googleSignInLauncher.launch(signInIntent)
            } catch (e: Exception) {
                Log.e("LoginActivity", "Error launching Google Sign-In: ${e.message}")
                viewModel.handleGoogleSignInError(e)
            }
        }

        binding.appleLoginButton.setOnClickListener {
            // Implement Apple Sign-In (e.g., using Firebase UI or native SDK)
        }

        binding.continueGuest.setOnClickListener {
            viewModel.signInAsGuest()
        }

        // Observe authentication state
        viewModel.authState.observe(this) { result ->
            result?.let {
                when {
                    it.isSuccess -> {
                        val user = it.getOrNull()
                        Log.d("LoginActivity", "Login successful: ${user?.email}")
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    }
                    it.isFailure -> {
                        Log.e("LoginActivity", "Login failed: ${it.exceptionOrNull()?.message}")
                        android.widget.Toast.makeText(
                            this,
                            "Login failed: ${it.exceptionOrNull()?.message}",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    }
}