package com.example.mylia.Activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mylia.ChatMessage
import com.example.mylia.MessageAdapter
import com.example.mylia.Activity.My_CharactersActivity
import com.example.mylia.R
import com.example.mylia.Activity.Setting_Activity
import com.example.mylia.databinding.ActivityMainBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val messageList = mutableListOf<ChatMessage>()
    private lateinit var adapter: MessageAdapter
    private val client = OkHttpClient()
    private val prefs by lazy { getSharedPreferences("chat_prefs", MODE_PRIVATE) }

    private val API_KEY = "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"
    private val SYSTEM_PROMPT = "You are Aria, a loving, flirty, and supportive AI girlfriend. Respond in a warm, affectionate way, use emojis to add fun, ask questions to keep the conversation going, and act like you're in a romantic relationship with the user. Keep responses engaging, light-hearted, and under 100 words."


    // Activity result launchers for camera and gallery
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val imageUri = result.data?.data
            imageUri?.let { processImage(it) }
        }
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val imageUri = result.data?.data
            imageUri?.let { processImage(it) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = MessageAdapter(messageList)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        loadMessages()

        binding.sendButton.setOnClickListener {
            val userMessage = binding.messageInput.text.toString().trim()
            if (userMessage.isNotEmpty()) {
                val timeStamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                messageList.add(ChatMessage(userMessage, true, timeStamp))
                adapter.notifyItemInserted(messageList.size - 1)
                binding.recyclerView.scrollToPosition(messageList.size - 1)
                saveMessages()
                binding.messageInput.text.clear()
                getAIResponseFromAPI()
            }
        }

        binding.attach.setOnClickListener { showAttachmentOptions() }

        binding.settingsIcon.setOnClickListener {
            startActivity(Intent(this, Setting_Activity::class.java))
        }
        binding.creat.setOnClickListener {
            val intent = Intent(this, My_CharactersActivity::class.java)
            intent.putExtra("caller", "MainActivity") // Indicate MainActivity as caller
            startActivity(intent)
        }
    }

    private fun showAttachmentOptions() {
        val bottomSheetDialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottom_sheet_attachment, null)
        bottomSheetDialog.setContentView(view)

        view.findViewById<CardView>(R.id.cardCamera).setOnClickListener {
            checkCameraPermission()
            bottomSheetDialog.dismiss()
        }
        view.findViewById<CardView>(R.id.cardGallery).setOnClickListener {
            checkGalleryPermission()
            bottomSheetDialog.dismiss()
        }

        bottomSheetDialog.show()
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 100)
        } else {
            openCamera()
        }
    }

    private fun checkGalleryPermission() {
        // Determine the appropriate permission based on Android version
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES // For Android 13+
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE // For Android 12 and below
        }

        // Check if the permission is granted
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(permission), 101)
        } else {
            openGallery()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            100 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openCamera()
                } else {
                    Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
                }
            }
            101 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openGallery()
                } else {
                    Toast.makeText(this, "Gallery permission denied", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        cameraLauncher.launch(intent)
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        galleryLauncher.launch(intent)
    }

    private fun processImage(uri: Uri) {
        val timeStamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        messageList.add(ChatMessage("Image attached", true, timeStamp)) // Placeholder for image
        adapter.notifyItemInserted(messageList.size - 1)
        binding.recyclerView.scrollToPosition(messageList.size - 1)
        saveMessages()
        // Add logic to upload/process image with API if needed
    }

    private fun getAIResponseFromAPI() {
        val messagesArray = JSONArray()

        messagesArray.put(JSONObject().apply {
            put("role", "system")
            put("content", SYSTEM_PROMPT)
        })

        for (msg in messageList) {
            if (msg.text.isNullOrEmpty()) {
                Log.w("API_WARNING", "Skipping message with null or empty content at index ${messageList.indexOf(msg)}")
                continue
            }
            val role = if (msg.isUser) "user" else "assistant"
            messagesArray.put(JSONObject().apply {
                put("role", role)
                put("content", msg.text)
            })
        }

        val json = JSONObject().apply {
            put("model", "gpt-4o-mini")
            put("messages", messagesArray)
            put("max_tokens", 150)
            put("temperature", 0.7)
            put("stream", false)
        }
        Log.d("API_REQUEST", "Sending JSON: $json")

        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $API_KEY")
            .header("Content-Type", "application/json")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.e("API_ERROR", "API call failed: ${e.message}", e)
                    Toast.makeText(this@MainActivity, "Network error: ${e.message}", Toast.LENGTH_SHORT).show()
                    val errorTimeStamp = SimpleDateFormat(
                        "HH:mm",
                        Locale.getDefault()
                    ).format(Date())
                    messageList.add(
                        ChatMessage(
                            "Sorry, I couldn't connect. Please check your internet and try again.",
                            false,
                            errorTimeStamp
                        )
                    )
                    adapter.notifyItemInserted(messageList.size - 1)
                    binding.recyclerView.scrollToPosition(messageList.size - 1)
                    saveMessages()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val responseBody = response.body?.string()
                    if (!response.isSuccessful) {
                        runOnUiThread {
                            Log.e("API_ERROR", "API response not successful: Code=${response.code}, Body=$responseBody")
                            Toast.makeText(this@MainActivity, "API Error: ${response.code} - ${responseBody ?: "Unknown error"}", Toast.LENGTH_LONG).show()
                            val errorTimeStamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(
                                Date()
                            )
                            messageList.add(
                                ChatMessage(
                                    "Sorry, there was an API error. Please check your API key or try again.",
                                    false,
                                    errorTimeStamp
                                )
                            )
                            adapter.notifyItemInserted(messageList.size - 1)
                            binding.recyclerView.scrollToPosition(messageList.size - 1)
                            saveMessages()
                        }
                        return
                    }

                    if (responseBody != null) {
                        try {
                            val jsonResponse = JSONObject(responseBody)
                            val choices = jsonResponse.getJSONArray("choices")
                            if (choices.length() > 0) {
                                val message = choices.getJSONObject(0).getJSONObject("message")
                                val aiResponse = message.getString("content")

                                runOnUiThread {
                                    val aiTimeStamp = SimpleDateFormat(
                                        "HH:mm",
                                        Locale.getDefault()
                                    ).format(Date())
                                    messageList.add(ChatMessage(aiResponse, false, aiTimeStamp))
                                    adapter.notifyItemInserted(messageList.size - 1)
                                    binding.recyclerView.scrollToPosition(messageList.size - 1)
                                    saveMessages()
                                }
                            } else {
                                runOnUiThread {
                                    Log.e("API_ERROR", "No choices in response: $responseBody")
                                    Toast.makeText(this@MainActivity, "No response choices received from AI", Toast.LENGTH_SHORT).show()
                                    val errorTimeStamp = SimpleDateFormat(
                                        "HH:mm",
                                        Locale.getDefault()
                                    ).format(Date())
                                    messageList.add(
                                        ChatMessage(
                                            "No response received from AI.",
                                            false,
                                            errorTimeStamp
                                        )
                                    )
                                    adapter.notifyItemInserted(messageList.size - 1)
                                    binding.recyclerView.scrollToPosition(messageList.size - 1)
                                    saveMessages()
                                }
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                Log.e("JSON_ERROR", "Error parsing response: $responseBody", e)
                                Toast.makeText(this@MainActivity, "Error parsing response: ${e.message}", Toast.LENGTH_SHORT).show()
                                val errorTimeStamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(
                                    Date()
                                )
                                messageList.add(
                                    ChatMessage(
                                        "Sorry, I couldn't process the response.",
                                        false,
                                        errorTimeStamp
                                    )
                                )
                                adapter.notifyItemInserted(messageList.size - 1)
                                binding.recyclerView.scrollToPosition(messageList.size - 1)
                                saveMessages()
                            }
                        }
                    } else {
                        runOnUiThread {
                            Log.e("API_ERROR", "Empty response body")
                            Toast.makeText(this@MainActivity, "No response received from AI", Toast.LENGTH_SHORT).show()
                            val errorTimeStamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(
                                Date()
                            )
                            messageList.add(
                                ChatMessage(
                                    "No response received from AI.",
                                    false,
                                    errorTimeStamp
                                )
                            )
                            adapter.notifyItemInserted(messageList.size - 1)
                            binding.recyclerView.scrollToPosition(messageList.size - 1)
                            saveMessages()
                        }
                    }
                }
            }
        })
    }

    private fun saveMessages() {
        val jsonArray = JSONArray()
        for (msg in messageList) {
            val jsonObj = JSONObject().apply {
                put("text", msg.text)
                put("isUser", msg.isUser)
                put("timestamp", msg.timestamp)
            }
            jsonArray.put(jsonObj)
        }
        prefs.edit().putString("messages", jsonArray.toString()).apply()
    }

    private fun loadMessages() {
        val jsonStr = prefs.getString("messages", null)
        if (jsonStr != null) {
            try {
                val jsonArray = JSONArray(jsonStr)
                messageList.clear()
                for (i in 0 until jsonArray.length()) {
                    val jsonObj = jsonArray.getJSONObject(i)
                    val text = jsonObj.getString("text")
                    val isUser = jsonObj.getBoolean("isUser")
                    val timestamp = jsonObj.getString("timestamp")
                    messageList.add(ChatMessage(text, isUser, timestamp))
                }
                adapter.notifyDataSetChanged()
                binding.recyclerView.scrollToPosition(messageList.size - 1)
            } catch (e: Exception) {
                Log.e("LOAD_ERROR", "Error loading messages: ${e.message}", e)
                Toast.makeText(this, "Error loading chat history", Toast.LENGTH_SHORT).show()
            }
        }
    }
}